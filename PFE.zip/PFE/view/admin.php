<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">



    <!--========== BOX ICONS ==========-->

    <link rel="stylesheet" href="view/assets/css/boxicons.min.css">

    <!--========== CSS ==========-->




    <title>Movietime</title>
    <link rel="icon" href="view/assets/img/icons8-film-reel-50.png">

</head>

<link rel="stylesheet" href="view/assets/css/bootstrap.min.css">
<link href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.0/css/bootstrap.min.css" rel="stylesheet" />

<link rel="stylesheet" href="view/assets/css/main.css">
<link rel="stylesheet" href="view/assets/css/admin.css">

<body>
    <!--========== HEADER ==========-->
    <header class="header">
        <div class="header__container">


            <div class="header__login">
            <a href="?action=logout" name="logout"> <i class='bx bx-log-in '></i> <input onclick="" class="btn text-light" type="button" value="Déconnexion" /></a></div>
            

         




            <a href="?action=auth" class="header__logo">Movie<span class="color-logo">time</span> </a>



            <div class="header__toggle">
                <i class="fa-solid fa-bars" id="header-toggle"></i>

            </div>
        </div>
    </header>


     












 <div class="container ">
 <h2 class="font-weight-light  text-secondary mb-5 "  >  Dashboard </h2>
    <div class="row " >
        <div class="col-md-5 col-xl-5">
            <div class="card bg-c-blue order-card bg-dark">
                <div class="card-block">
                    
                <a href="?action=AddMo_Se" class="tex"><h6 class="m-b-20 tex" ><i class='bx bxs-movie bx-md' style='color:#fffefe' ></i>  
Ajouter film ou série </h6></a>
                          
                </div>
            </div>
        </div>
        
        <div class="col-md-5 col-xl-5">
            <div class="card bg-c-green order-card bg-dark">
                     <div class="card-block">
                    
                    <a href="?action=add_Act" class="tex"><h6 class="m-b-20 tex" > <i class='bx bx-face bx-md' style='color:#fffefe' ></i> Ajouter un acteur</h6></a>
                              
                    </div>
            </div>
        </div>
       
        <div class="col-md-5 col-xl-5">
            <div class="card bg-c-green order-card bg-dark">
                     <div class="card-block">
                    
                    <a href="?action=addCastL" class="tex"><h6 class="m-b-20 tex" > <i class='bx bx-face bx-md' style='color:#fffefe' ></i> Ajouter  principale</h6></a>
                              
                    </div>
            </div>
        </div>
        
        <div class="col-md-5 col-xl-5">
            <div class="card bg-c-yellow order-card bg-dark">
            <div class="card-block">
                    
                    <a href="?action=dem" class="tex"><h6 class="m-b-20 tex" ><i class='bx bx-mail-send bx-md' style='color:#fffefe' ></i>  Demandes</h6></a>
                              
                    </div>
            </div>
        </div>
        
       
	</div>
</div>
    </body>

</html>