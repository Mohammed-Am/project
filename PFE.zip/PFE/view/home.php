<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">



    <!--========== BOX ICONS ==========-->

    <link rel="stylesheet" href="view/assets/css/boxicons.min.css">

    <!--========== Bootstrap ==========-->

    <link rel="stylesheet" href="view/assets/css/bootstrap.min.css">
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.0/css/bootstrap.min.css" rel="stylesheet" />


    <!--========== CSS ==========-->

    <link rel="stylesheet" href="view/assets/css/main.css">

    <!--========== Icons title ==========-->

    <link rel="icon" href="view/assets/img/icons8-film-reel-50.png">

    <title>Movietime</title>




</head>




<?php


?>

<body>
    <!--========== HEADER ==========-->
    <header class="header">
        <div class="header__container">


            <div class="header__login">
                 <input onclick="document.getElementById('id01').style.display='block'" class="header_btn" name="login" type="button" value="Connexion" />
                <input onclick="document.getElementById('id02').style.display='block'" class="header_btn" type="button" value="S'inscrire" />
            </div>
            <!-- Login form -->
            <div id="id01" class="modal">

                <form class="modal-content animate" action="?action=auth" method="post">
                    <div class="imgcontainer">
                        <span onclick="document.getElementById('id01').style.display='none'" class="close" title="Close Modal">&times;</span>
                        <h1>Connexion</h1>
                    </div>

                    <div class="container">
                        <label for="uname"><b>Nom d'utilisateur</b></label>
                        <input type="text" style=" color : whitesmoke; " name="uname" required>

                        <label for="psw"><b>Mot de passe</b></label>
                        <input type="password" style=" color : whitesmoke; " name="psw" required>

                        <button class="blr" type="submit" name="login">Connexion</button>
                        <label>
                            <input type="checkbox" checked="checked" name="remember"> Remember me
                        </label>
                        <span class="psw"><a href="#"> Mot de passe oublié ?</a></span>
                    </div>

                    <h5 class="text-white">Vous n'avez pas de compte ? <a href=""> Inscrivez-vous ici !</a> </h5>

                </form>

            </div>

            <!-- Resister form -->
            <div id="id02" class="modal">

                <form class="modal-content animate" action="?action=addUser" method="post">
                    <div class="imgcontainer">
                        <span onclick="document.getElementById('id02').style.display='none'" class="close" title="Close Modal">&times;</span>
                        <h1>Créer un compte</h1>
                    </div>

                    <div class="container">
                        <label for="uname"><b>Nom d'utilisateur</b></label>
                        <input type="text" style=" color : whitesmoke; " name="uname" required>

                        

                        <label for="psw"><b>Mot de passe</b></label>
                        <input type="password" style=" color : whitesmoke; " placeholder="at least 8 charcters" name="psw" required>

                        <label for="psw"><b>Confirmer le mot de passe</b></label>
                        <input type="password" style=" color : whitesmoke; " name="psw1" required>



                        <button class="blr" type="submit" name="regist">S'inscrire</button>

                    </div>



                </form>
            </div>




            <a href="index.php" class="header__logo">Movie<span class="color-logo">time</span> </a>



            <div class="header__toggle">
                <i class="fa-solid fa-bars" id="header-toggle"></i>

            </div>
        </div>
    </header>
    <!--========== NAV ==========-->
    <div class="nav" id="navbar">
        <nav class="nav__container">
            <div>
                <a href="#" onclick="document.getElementById('id01').style.display='block'" class="nav__link nav__logo">
                    <i class='fa-solid fa-compact-disc nav__icon'></i>
                    <span class="nav__logo-name">Movie<span class="color-logo">time</span></span>
                </a>

                <div class="nav__list">
                    <div class="nav__items">
                        <h3 class="nav__subtitle">Découvrir</h3>


                        <div class="nav__dropdown">
                            <a href="#" onclick="document.getElementById('id01').style.display='block'" class="nav__link">
                                <i class='bx bx-camera-movie nav__icon'></i>
                                <span class="nav__name">Films</span>
                                <!-- <i class='bx bx-chevron-down nav__icon nav__dropdown-icon'></i> -->
                            </a>


                        </div>

                        <div class="nav__dropdown">
                            <a href="#" onclick="document.getElementById('id01').style.display='block'" class="nav__link">
                                <i class='bx bx-tv nav__icon'></i>
                                <span class="nav__name">TV-Series</span>
                            </a>
                        </div>

                        <div class="nav__dropdown">
                            <a href="#" onclick="document.getElementById('id01').style.display='block'" class="nav__link">
                                <i class='bx bx-category-alt nav__icon'></i>
                                <span class="nav__name">Genre</span>
                                <i class='bx bx-chevron-down nav__icon nav__dropdown-icon'></i>
                            </a>


                            <div class="nav__dropdown-collapse">
                                <div class="nav__dropdown-content">
                                    <a href="#" onclick="document.getElementById('id01').style.display='block'" class="nav__dropdown-item">Animation </a>
                                    <a href="#" onclick="document.getElementById('id01').style.display='block'" class="nav__dropdown-item">Documentary</a>
                                    <a href="#" onclick="document.getElementById('id01').style.display='block'" class="nav__dropdown-item">Action</a>
                                    <a href="#" onclick="document.getElementById('id01').style.display='block'" class="nav__dropdown-item">History </a>
                                    <a href="#" onclick="document.getElementById('id01').style.display='block'" class="nav__dropdown-item">War</a>
                                    <a href="#" onclick="document.getElementById('id01').style.display='block'" class="nav__dropdown-item">Comedy</a>
                                    <a href="#" onclick="document.getElementById('id01').style.display='block'" class="nav__dropdown-item">Horror</a>
                                    <a href="#" onclick="document.getElementById('id01').style.display='block'" class="nav__dropdown-item">Biographyy </a>
                                    <a href="#" onclick="document.getElementById('id01').style.display='block'" class="nav__dropdown-item">Family</a>
                                    <a href="#" onclick="document.getElementById('id01').style.display='block'" class="nav__dropdown-item">Adventure</a>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="nav__dropdown">
                        <a href="#" onclick="document.getElementById('id01').style.display='block'" class="nav__link">
                            <i class='bx bx-face nav__icon'></i>
                            <span class="nav__name">Acteurs</span>
                        </a>


                    </div>


                </div>




            </div>
    </div>



    </nav>
    </div>

    <!--========== CONTENTS ==========-->
    <main>



        <section class="banner ">
            <div class="banner-card  " >
                <div id="carousel-slider " class="carousel slide carousel-fade " data-ride="carousel" data-interval="5000">
                    <!--Indicators-->
                    <ol class="carousel-indicators">
                        <li data-target="#carousel-slider" data-slide-to="0" class="active"></li>
                        <li data-target="#carousel-slider" data-slide-to="1"></li>
                        <li data-target="#carousel-slider" data-slide-to="2"></li>
                        <li data-target="#carousel-slider" data-slide-to="3"></li>
                        <li data-target="#carousel-slider" data-slide-to="4"></li>
                        <li data-target="#carousel-slider" data-slide-to="5"></li>
                    </ol>
                    <!--Indicators-->
                    <!--Slides-->
                    <div class="carousel-inner" role="listbox">
                        <!--First slide-->
                        <div class="carousel-item active">
                                 <img class="d-block w-100 m-25  " src="view/assets/img/img1.JPG" alt="First slide">
                            <div class="content5">
                                <h1>The Gray Man</h1>
                                <p>Quand l'agent le plus doué de la CIA découvre accidentellement les sombres secrets des services de renseignement américains, un ex-collègue tueur aux tendances psychopathes met sa tête à prix.</p>
                                <!-- Use a button to pause/play the video with JavaScript -->

                                <button id="myBtn" onclick="document.getElementById('id01').style.display='block'"><i class='bx bx-bookmark bx-xs'></i>Watchlist</button>
                            </div>
                        </div>

                        <!--/First slide-->
                        <!--Second slide-->
                        <div class="carousel-item">
                        <img class="d-block w-100" src="view/assets/img/img2.JPG" alt="First slide">

                            <div class="content5">
                                <h1>Extraction</h1>
                                <p>A hardened mercenary's mission becomes a soul-searching race to survive when he's sent into Bangladesh to rescue a drug lord's kidnapped son.</p>
                                <!-- Use a button to pause/play the video with JavaScript -->
                                <button id="myBtn" onclick="document.getElementById('id01').style.display='block'"><i class='bx bx-bookmark bx-xs'></i>Watchlist</button>
                            </div>
                        </div>
                        <!--/Second slide-->
                        <!--Third slide-->
                        <div class="carousel-item">
                        <img class="d-block w-100" src="view/assets/img/img3.jpg" alt="First slide">
                            <div class="content5">
                                <h1>Against The Ice </h1>
                                <p>Exploring Greenland's vast landscape for a lost map, two men must fight to survive. Based on the true story of Denmark's 1909 polar expedition.</p>
                                <!-- Use a button to pause/play the video with JavaScript -->
                                <button id="myBtn" onclick="document.getElementById('id01').style.display='block'"><i class='bx bx-bookmark bx-xs'></i>Watchlist</button>
                            </div>
                        </div>
                        <!--/Third slide-->
                        <!--Forth slide-->
                        <div class="carousel-item">
                        <img class="d-block w-100" src="view/assets/img/img4.jpg" alt="First slide">

                            <div class="content5">
                                <h1>Dunkerque</h1>
                                <p>En mai 1940, soldats et civils tentent dans un ultime espoir d'évacuer par voie terrestre, marine et aérienne l'armée britannique et ses alliés encerclés à Dunkerque.</p>
                                <!-- Use a button to pause/play the video with JavaScript -->
                                <button id="myBtn" onclick="document.getElementById('id01').style.display='block'"><i class='bx bx-bookmark bx-xs'></i>Watchlist</button>
                            </div>
                        </div>
                        <!--/Forth slide-->
                        <!--Third slide-->
                        <div class="carousel-item">

                            <img class="d-block w-100" src="view/assets/img/img5.jpg" alt="First slide">

                            <div class="content5">
                            <h1>Don't Look Up</h1>
                                <p>Two astronomers go on a media tour to warn humankind of a planet-killing comet hurtling toward Earth. The response from a distracted world: Meh.</p>
                                <!-- Use a button to pause/play the video with JavaScript -->
                                <button id="myBtn" onclick="document.getElementById('id01').style.display='block'"><i class='bx bx-bookmark bx-xs'></i>Watchlist</button>
                            </div>
                        </div>
                        <!--/Third slide-->
                        <!--Forth slide-->
                        <div class="carousel-item">

                            <img class="d-block w-100" src="view/assets/img/img6.jpg" alt="First slide">

                            <div class="content5">
                                <h1>Bright: Samurai Soul</h1>
                                <p>In the early years of Japan's Meiji Restoration, a human ronin must unite with an orc assassin to save an elf orphan from their common adversary</p>
                                <!-- Use a button to pause/play the video with JavaScript -->
                                <button id="myBtn" onclick="document.getElementById('id01').style.display='block'"><i class='bx bx-bookmark bx-xs'></i>Watchlist</button>
                            </div>
                        </div>
                        <!--/Forth slide-->
                    </div>
                </div>
            </div>




        </section>


    
        <div class="container mx-auto  ">

            <h4 class="font-weight-light text-secondary">Recommandée</h4>

            <!-- movies grid -->
            <?php
            $con = conect();
            $sql = 'SELECT * FROM movies_tv';
            $tab = $con->query($sql)->fetchAll(PDO::FETCH_ASSOC);
            foreach ($tab  as $row) {

            ?>


                <form action="" method="post" style="display:grid;
                                grid-row:1 ;
                                grid-template-columns: repeat(auto-fill,minmax(140px, 1fr));
                                gap:52px;
                                margin-bottom:10px;">
                    <div class="card  rounded  row gy-2" class="col-md-4" style="width: 13rem; margin-top:18px; background-color:#1A1A1A;"> 


                        <a href="#" onclick="document.getElementById('id01').style.display='block'"> <img class=" img-fluid" style="width: 100%; height: 20vw; object-fit: cover;" src="view/image/<?= $row['image'] ?>" alt="" style="hight=80%"> </a>
                        <div class="card-body   ">

                            <span class="circle-icon text-secondary"><i class='bx bxs-star bx-sm  nav__icon' style="color: gold ;"></i><span style="font-size: 22px ; font-weight: bold;"><?= $row['vote'] ?></span>
                                <a href="#">
                                    <p class="card-text fs-7 text-light "><?= $row['title'] ?></p>
                                </a>


                                <a href="#"><button type="button" style="color-background:#515151;"><i class='bx bx-plus'></i> Watchlist</button></a>
                                <a href=""><button type="button" class="btn   text-white"> <i class='bx bx-play'></i>Trailer</button></a>
                        </div>





                    </div>
                <?php
            }
                ?>


                </form>



        </div>








    </main>
    <link rel="stylesheet" href="view/assets/css/main.css">


    <!-- STRAT FOOTER -->

    <div class="footer">
        <div class="container_footer">
            <span class="logo-footr">Movie<span class="lg-span">time</span></span>
            <p>Movietime est une base de données en ligne d'informations qui propose une grande variété d'émissions de télévision, de films, d'animes, de documentaires et bien plus encore sur des milliers d'appareils connectés à Internet.</p>



            <div class="links">
                <a href="#" onclick="document.getElementById('id03').style.display='block'" class="req">Demande</a>
                <a href="#" class="req">About Us</a>
                <a href="#" class="req">Privacy</a>


                <div class="social-icons">

                    <a class="icon" href="#"><i class='bx bxl-twitter bx-sm' style="color: #00acc1;"></i> Connect with us on twitter</a>

                </div>
            </div>








        </div>

    </div>



    <!-- END FOOTER -->


    <div class="header__container">


        <!-- Request form -->
        <div id="id03" class="modal">

            <form class="modal-content animate" method="post">
                <div class="imgcontainer">
                    <span onclick="document.getElementById('id03').style.display='none'" class="close" title="Close Modal">&times;</span>
                    <h1 class="fon">Envoyez votre demande </h1>
                    <p>Si votre film/émission n'est pas répertorié dans notre bibliothèque, vous pouvez soumettre votre demande ici, nous essaierons de la rendre disponible dès que possible ! </p>
                </div>

                <div class="container">
                    <label for="uname"><b>Email</b></label>
                    <input type="text" style=" color : whitesmoke; " placeholder="Votre email" name="uname" required>

                    <label for="title"><b>Titre</b></label>
                    <input type="text" style=" color : whitesmoke; " placeholder="Entrez le nom de votre film/émission" name="title" required>

                    <label for="des"><b>Description</b></label>
                    <input type="text" style=" color : whitesmoke; " placeholder="Lien IMDB si possible" name="des">

                    <button class="blr" type="submit" name="login">Send Request </button>



                </div>



            </form>

        </div>



        <!--========== MAIN JS ==========-->


        <script>
            // Get the modal
            var modal1 = document.getElementById('id01');
            var modal2 = document.getElementById('id02');
            var modal3 = document.getElementById('id03');

            // When the user clicks anywhere outside of the modal, close it
            window.onclick = function(event) {
                if (event.target == modal1) {
                    modal1.style.display = "none";

                }

                if (event.target == modal2) {
                    modal2.style.display = "none";

                }
                if (event.target == modal3) {
                    modal3.style.display = "none";

                }
            }
        </script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.0/umd/popper.min.js"></script>
        <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.0/js/bootstrap.min.js"></script>



</body>

</html>