<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!--========== BOX ICONS ==========-->
    <link rel="stylesheet" href="view/assets/css/boxicons.min.css">
    <!--========== CSS ==========-->
    <title>Admin</title>
    <link rel="icon" href="view/assets/img/icons8-film-reel-50.png">
</head>
<link rel="stylesheet" href="view/assets/css/bootstrap.min.css">
<!-- <link rel="stylesheet" href="../view/image/"> -->
<link rel="stylesheet" href="view/assets/css/main.css">
<link rel="stylesheet" href="../view/image/">
<!--========== HEADER ==========-->
<header class="header">
    <div class="header__container">
        <div class="header__login">
            <a href="?action=logout" name="logout"> <i class='bx bx-log-in '></i> <input onclick="document.getElementById('id01').style.display='block'" class="btn text-light" type="button" value="Sign out" /></a>
        </div>
        <!-- Login form -->
        <div id="id01" class="modal">

            <form class="modal-content animate" action="" method="post">
                <div class="imgcontainer">
                    <span onclick="document.getElementById('id01').style.display='none'" class="close" title="Close Modal">&times;</span>
                    <h1>Sign In</h1>
                </div>



                <h5>Don't have an account? <a href=""> Sign up here!</a> </h5>

            </form>

        </div>

        <!-- Resister form -->
        <div id="id02" class="modal">

            <form class="modal-content animate" action="" method="post">
                <div class="imgcontainer">
                    <span onclick="document.getElementById('id02').style.display='none'" class="close" title="Close Modal">&times;</span>
                    <h1>Create account</h1>
                </div>

                <div class="container">
                    <label for="uname"><b>Username</b></label>
                    <input type="text" style=" color : whitesmoke; " name="uname" required>

                    <label for="psw"><b>Email</b></label>
                    <input type="email" style=" color : whitesmoke; " name="email" required>

                    <label for="psw"><b>Password </b></label>
                    <input type="password" style=" color : whitesmoke; " placeholder="at least 8 charcters" name="psw" required>

                    <label for="psw"><b>Password Confirm</b></label>
                    <input type="password" style=" color : whitesmoke; " name="psw1" required>



                    <button class="blr" type="submit" name="regist">Sign Up</button>

                </div>



            </form>
        </div>




        <a href="?action=auth" class="header__logo">Movie<span class="color-logo">time</span> </a>



        <div class="header__toggle">
            <i class="fa-solid fa-bars" id="header-toggle"></i>

        </div>
    </div>
</header>

<body>
    <h3 style="text-align:center; color:#ddd;" class="m-5">Ajouter un acteur </h3>



    <form action="" method="post">
        <input style="color: white ;"  type="text" name="film" required>
        <input type="submit" class="header_btn  d-flex justify-content-center text-light  ">
    </form>
    <?php


    if (isset($_POST['film'])) {
        $film = $_POST['film'];
        $con = conect();
        $sql = "SELECT count(*) FROM movies_tv where title='$film'";
        $tabb = $con->query($sql)->fetchAll();

        if ($tabb[0][0] > 0) {
            $sql = "SELECT * FROM movies_tv where title='$film'";
            $tab = $con->query($sql)->fetchAll();
            foreach ($tab  as $row) {
                // echo  $row['idMovies'][0];
            }
    ?>
            <form action="?action=addCastL&id=<?= $row['idMovies']; ?>" enctype="multipart/form-data" method="post">

                <div class="row justify-content-between text-left">

                    <div>
                        <br>
                        <h4 class="text-info "><em>Actor</em></h4>
                    </div>
                    <div class="form-group col-sm-4 flex-column d-flex">
                        <label class="form-control-label px-3">Name cast :</label>
                        <input type="text" name="acn1" class="text-light " placeholder="Describe your Film" required>
                    </div>

                    <div class="form-group col-sm-4 flex-column d-flex">
                        <label class="form-control-label px-3">Nick cast :</label>
                        <input type="text" class="text-light " name="nc1" placeholder="Enter your first name">
                    </div>
                    <br>
                    <div>
                        <br>
                        <label for="img">Image :</label>
                        <input type="file" name="image">
                    </div>
                    <br>
                    <div>
                        <br>
                        <input type="submit" name="sub" value="VALID" class="header_btn">
                        <input type="reset" value="Annuler" class="header_btn">
                    </div>
                </div>
            </form>
            <br>

            </div>

    <?php
        } elseif ($tabb[0][0] == 0) {
            echo " <h4 style='text-align:center; color:#ddd;' class='m-5'>No Film  </h3>";
        }
    }
    ?>
    <a href="?action=auth" class="btn btn-secondary d-block w-25 mx-auto"> <i class='bx  bx-arrow-back' style='color:#ffffff'></i>Back to dashboard</a>

</body>

</html>