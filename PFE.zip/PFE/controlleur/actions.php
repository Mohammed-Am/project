<?php include_once('modele/conect.php');
session_start();
function login($u, $p)
{
    include_once('modele/conect.php');
    $con = conect();
    $req = "SELECT * from user  where login=:u and pwd=:p";
    $st = $con->prepare($req);
    $st->execute(['u' => $u, 'p' => $p]);
    $tabb = $st->fetchAll();
    //print_r($tab);
    if (count($tabb) == 0) {
        // unset($_SESSION["user"]);
        include_once('view/home.php');
    } elseif ($tabb[0][3] == 'user') {
        $req = "SELECT * from user where login=:u
                and pwd=:p ";
        $st = $con->prepare($req);
        $st->execute(['u' => $u, 'p' => $p]);
        $tab = $st->fetchAll();
        $_SESSION["idUser"] = $tab[0][0];
        $_SESSION["user"] = $tab[0][1];
        $_SESSION["pwd"] = $tab[0][2];
        $_SESSION['type'] = $tab[0][3];
        include_once('view/homelog.php');
    } elseif ($tabb[0][3] == 'admin') {
        // $_SESSION["idUser"] = $tab[0][0];
        $_SESSION["user"] = $tabb[0][1];
        $_SESSION["pwd"] = $tabb[0][2];
        $_SESSION['type'] = $tabb[0][3];
        include_once('view/admin.php');
    }
}
function logout()
{
    $_SESSION = array();
    if (ini_get("session.use_cookies")) {
        $params = session_get_cookie_params();
        setcookie(
            session_name(),
            '',
            time() - 42000,
            $params["path"],
            $params["domain"],
            $params["secure"],
            $params["httponly"]
        );
    }
}

function newUser()
{
    if (isset($_POST['regist'])) {
        include_once('modele/conect.php');
        $u = $_POST['uname'];
        $p = $_POST['psw'];
        $p1 = $_POST['psw1'];
        if ($p != $p1) {
            echo '<script>alert("VALID YOUR PASSWORD");</script>';
            return;
        } else {
            $con = conect();
            $sql = "INSERT INTO user (login,pwd) VALUES (?,?)";
            $stmt = $con->prepare($sql);
            $stmt->execute(array($u, $p));
        }
    }
}
function addList()
{
    if (isset($_POST['addList'])) {
    }
}
function watchlist()
{
    $id = $_GET['id'];
    $con = conect();
    $sql = 'SELECT * FROM movies_tv WHERE idMovies=' . $id;
    $tab = $con->query($sql)->fetchAll();
    $sql1 = 'SELECT count(*) FROM playlist WHERE idUser=' . $_SESSION['idUser'] . ' AND idMovies=' . $_GET['id'];
    $tabb = $con->query($sql1)->fetchAll();
    if ($tabb[0][0] > 0) {
        echo "<script>alert('Alredy in WatchList');</script>";
        include('view/homelog.php');
        return;
    } else {
        foreach ($tab as $row) {
            $n = $row['title'];
            $img = $row['image'];
            $ty = $row['MorS'];
            $time = $row['time'];
            $idU = $_SESSION["idUser"];
            $sql = 'INSERT INTO playlist( title , image , type , time , idUser , idMovies) 
                           VALUE( ? , ? , ? , ? , ? , ? )';
            $stmt = $con->prepare($sql);
            $stmt->execute(array($n, $img, $ty, $time, $idU, $id));

            include('view/homelog.php');
        }
    }
}
function watchFilm()
{
    $id = $_GET['id'];
    $con = conect();
    $sql = 'SELECT * FROM movies_tv WHERE idMovies=' . $id;
    $tab = $con->query($sql)->fetchAll();
    $sql1 = 'SELECT count(*) FROM playlist WHERE idUser=' . $_SESSION['idUser'] . ' AND idMovies=' . $_GET['id'];
    $tabb = $con->query($sql1)->fetchAll();
    if ($tabb[0][0] > 0) {
        echo "<script>alert('Alredy in WatchList');</script>";
        include('view/film.php');
        return;
    } else {
        foreach ($tab as $row) {
            $n = $row['title'];
            $img = $row['image'];
            $ty = $row['MorS'];
            $time = $row['time'];
            $idU = $_SESSION["idUser"];
            $sql = 'INSERT INTO playlist( title , image , type , time , idUser , idMovies) 
                           VALUE( ? , ? , ? , ? , ? , ? )';
            $stmt = $con->prepare($sql);
            $stmt->execute(array($n, $img, $ty, $time, $idU, $id));

            include('view/film.php');
        }
    }
}
function watchSerie()
{
    $id = $_GET['id'];
    $con = conect();
    $sql = 'SELECT * FROM movies_tv WHERE idMovies=' . $id;
    $tab = $con->query($sql)->fetchAll();
    $sql1 = 'SELECT count(*) FROM playlist WHERE idUser=' . $_SESSION['idUser'] . ' AND idMovies=' . $_GET['id'];
    $tabb = $con->query($sql1)->fetchAll();
    if ($tabb[0][0] > 0) {
        echo "<script>alert('Alredy in WatchList');</script>";
        include('view/series.php');
        return;
    } else {
        foreach ($tab as $row) {
            $n = $row['title'];
            $img = $row['image'];
            $ty = $row['MorS'];
            $time = $row['time'];
            $idU = $_SESSION["idUser"];
            $sql = 'INSERT INTO playlist( title , image , type , time , idUser , idMovies) 
                           VALUE( ? , ? , ? , ? , ? , ? )';
            $stmt = $con->prepare($sql);
            $stmt->execute(array($n, $img, $ty, $time, $idU, $id));

            include('view/series.php');
        }
    }
}
function search()
{
?>
<div class="container mx-auto ">
<h4 class="font-weight-light text-secondary m-5" style="margin-top : 40px;">RESULT</h4>

    <?php $con = conect();
    if (isset($_POST['search']) && isset($_POST['send'])) {
        $title = $_POST['search'];
        $sql = "SELECT count(*) FROM movies_tv WHERE title LIKE '%$title%'";
        $tab1 = $con->query($sql)->fetchAll();
        if ($tab1[0][0] > 0) {
            $sql = "SELECT * FROM movies_tv WHERE title LIKE '%$title%'";
            $tab = $con->query($sql)->fetchAll();
            ?>
                <form action="?action=playList" method="post" style="display:grid;
                                                                     grid-row:1 ;
                                                                     grid-template-columns: repeat(auto-fill,minmax(140px, 1fr));
                                                                     gap:50px;
                                                                     margin-bottom:10px;">
                    <?php foreach ($tab  as $row) {
                    ?>
                        <div class="card  rounded  row" class="col-md-4" style="width: 13rem; margin-top:38px; background-color:#1A1A1A;">
                            <a href="view/movie.php?id=<?= $row['idMovies'] ?>"> <img src="view/image/<?= $row['image'] ?>" alt=""> </a>
                            <div class="card-body">
                                <a href="view/movie.php?$_POST['idMovies']">
                                    <h3 class="card-text fs-5"><?= $row['title'] ?></h3>
                                </a>
                                <span class="card-text .text-secondary"><?= $row['type'] ?></span>
                                <br>
                                <span class="card-text .text-secondary"><?= $row['time'] ?></span>
                                <a href="?action=insert&id=<?= $row['idMovies'] ?>"><button type="button" style="color-background:#515151;"><i class='bx bxs-bookmark'></i>Watchlist</button></a>
                                <a href=""><button type="button" class="btn d-flex justify-content-center text-light "> <i class='bx bx-play'></i>Trailer</button></a>
                            </div>
                        </div>
                </form>

                </main>

            <?php
                    }
                }
                if ($tab1[0][0] == 0) {
            ?>
            <h4 class="font-weight-light text-secondary" style="margin-top : 40px;">No RESULT</h4>
    <?php }
            }
    ?>
    <!-- STRAT FOOTER -->

    <div class="footer">
        <div class="container_footer">
            <span class="logo-footr">Movie<span class="lg-span">time</span></span>
            <p>Movietime est une base de données en ligne d'informations qui propose une grande variété d'émissions de télévision, de films, d'animes, de documentaires et bien plus encore sur des milliers d'appareils connectés à Internet.</p>



            <div class="links">
                <a href="#" onclick="document.getElementById('id03').style.display='block'" class="req">Demande</a>
                <a href="#" class="req">About Us</a>
                <a href="#" class="req">Privacy</a>


                <div class="social-icons">

                    <a class="icon" href="#"><i class='bx bxl-twitter bx-sm' style="color: #00acc1;"></i> Connect with us on twitter</a>

                </div>
            </div>








        </div>

    </div>



    <!-- END FOOTER -->


    <div class="header__container">


        <!-- Request form -->
        <div id="id03" class="modal">

            <form class="modal-content animate" action="?action=sendD" method="post">
                <div class="imgcontainer">
                    <span onclick="document.getElementById('id03').style.display='none'" class="close" title="Close Modal">&times;</span>
                    <h1 class="fon">Envoyez votre demande </h1>
                    <p>Si votre film/émission n'est pas répertorié dans notre bibliothèque, vous pouvez soumettre votre demande ici, nous essaierons de la rendre disponible dès que possible ! </p>
                </div>

                <div class="container">
                    <label for="uname"><b>Email :</b></label>
                    <input type="text" style=" color : whitesmoke; " placeholder="Votre email" name="email" required>

                    <label for="title"><b>Titre :</b></label>
                    <input type="text" style=" color : whitesmoke; " placeholder="Entrez le nom de votre film/émission" name="title" required>

                    <label for="des"><b>Lien IMDB :</b></label>
                    <input type="text" style=" color : whitesmoke; " placeholder="Lien IMDB si possible" name="url">

                    <a href=""><button class="blr" type="submit" name="sub">Send Request </button></a>
                </div>

            </form>

        </div>



        <!-- END FOOTER -->


        <!--========== MAIN JS ==========-->


        <script>
            // Get the modal
            var modal1 = document.getElementById('id01');
            var modal2 = document.getElementById('id02');

            // When the user clicks anywhere outside of the modal, close it
            window.onclick = function(event) {
                if (event.target == modal1) {
                    modal1.style.display = "none";

                }

                if (event.target == modal2) {
                    modal2.style.display = "none";

                }
            }
        </script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.0/umd/popper.min.js"></script>
        <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.0/js/bootstrap.min.js"></script>



    <?php  }

function addMS()
{
    if (isset($_POST['sub'])) {
        $from = $_FILES['image']['tmp_name'];
        $to = $_FILES['image']['name'];
        $mv =  move_uploaded_file($from, "view/image/" . $to);

        $title = $_POST['title'];
        $time = $_POST['time'];

        $date = $_POST['date'];
        $desc = $_POST['desc'];
        $der  = $_POST['der'];

        $cont = $_POST['count'];
        $rate = $_POST['rate'];
        $type = $_POST['type'];
        $mors = $_POST['mors'];
        $leng = $_POST['leng'];
        $link = $_POST['link'];

        $img = $to;

        $con = conect();
        $sql = "INSERT INTO `movies_tv` (`idMovies`, `title`, `image`, `time`, `date`, `describe`, `director`, `country`,`vote`,`type`, `MorS` , `Language` , `link_trailer`) 
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ? ,? ,? ,? );";
        $stmt = $con->prepare($sql);
        $stmt->execute(array(
            null, $title, $to, $time, $date, $desc, $der, $cont, $rate, $type, $mors, $leng, $link
        ));
        echo '<script>alert("Film inserted successfully.");</script>';
    }
}
function addAct()
{
    if (isset($_POST['sub'])) {
        $from = $_FILES['img']['tmp_name'];
        $to = $_FILES['img']['name'];
        $mv =  move_uploaded_file($from, "view/imageAc/" . $to);

        $act = $_POST['act'];
        $actB = $_POST['actB'];

        $actD = $_POST['actD'];
        $actF = $_POST['actF'];
        $con = conect();
        $sql = "INSERT INTO `acteur` (`idAct`, `ActName`, `ActBorn`, `ActDesc`, `ActFS` ,`ActImg`) 
                        VALUES (?, ?, ?, ?, ? , ?);";
        $stmt = $con->prepare($sql);
        $stmt->execute(array(
            null, $act, $actB, $actD, $actF, $to
        ));
        echo '<script>alert("Actoe inserted successfully.");</script>';
    }
}
function sendD()
{
    if (isset($_POST['sub'])) {

        $email = $_POST['email'];
        $title = $_POST['title'];
        $url = $_POST['url'];

        $con = conect();
        $sql = "INSERT INTO `demande` (`idDem`, `email`, `titre`, `URL`) VALUES (?, ?, ?, ?);";
        $stmt = $con->prepare($sql);
        $stmt->execute(array(
            null, $email, $title, $url
        ));
        echo '<script>alert("Demande envoyer.");</script>';
    }
}
function addCastL()
{
    if (isset($_SESSION["user"]) && $_SESSION["type"] == "admin") {
        // addAct();
        if (isset($_SESSION['user']) && $_SESSION['type'] == "admin") {
            if (isset($_POST['sub'])) {
                include_once('modele/conect.php');

                $from = $_FILES['image']['tmp_name'];
                $to = $_FILES['image']['name'];
                $mv =  move_uploaded_file($from, "view/imageAc/" . $to);

                $con = conect();
                $id = $_GET['id'];
                $acn1 = $_POST['acn1'];
                $nc1 = $_POST['nc1'];

                $sql = "SELECT count(*) FROM castlist where idMovies=" . $id;
                $tab1 = $con->query($sql)->fetchAll();

                if ($tab1[0][0] > 5) {
                    echo "<script>alert('Cast  if Full ');</script>";
                } else {
                    $sql = "INSERT INTO `castlist`(`idMovies`, `nameCast`, `nickCast`, `imageCast`)  
                  VALUES ( ?, ?, ?, ?);";
                    $stmt = $con->prepare($sql);
                    $stmt->execute(array(
                        $id, $acn1, $nc1, $to
                    ));
                    echo "<script>alert('Cast List Inserted ');</script>";
                }
            }
        }
    }
}
